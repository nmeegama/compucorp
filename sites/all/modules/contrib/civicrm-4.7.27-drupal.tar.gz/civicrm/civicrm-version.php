<?php
function civicrmVersion( ) {
  return array( 'version'  => '4.7.27',
                'cms'      => 'Drupal',
                'revision' => '' );
}

