<?php
namespace Civi\Payment\Exception;

/**
 * Class PaymentProcessorException
 */
class PaymentProcessorException extends \CRM_Core_Exception {

}
