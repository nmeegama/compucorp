<?php
namespace Civi\Core\Exception;

class UnknownAssetException extends \CRM_Core_Exception {

}
