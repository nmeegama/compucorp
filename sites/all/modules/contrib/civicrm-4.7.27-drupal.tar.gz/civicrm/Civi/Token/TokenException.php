<?php
namespace Civi\Token;

class TokenException extends \CRM_Core_Exception {

}
